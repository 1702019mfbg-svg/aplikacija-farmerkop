<?php
/**
 * Radnik – unos proizvodnje.
 */
declare(strict_types=1);
require __DIR__ . '/../inc/bootstrap.php';
require __DIR__ . '/../inc/radnik_stranica.php';

radnik_stranica('proizvodnja');
